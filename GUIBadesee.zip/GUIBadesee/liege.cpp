#include "liege.h"

Liege::Liege() {}
