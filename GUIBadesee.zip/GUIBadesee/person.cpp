#include "person.h"


Person::Person() {}

int Person::Personenanzahlzumtestsetzen(Person* p){
    personen.push_back(p);
}
