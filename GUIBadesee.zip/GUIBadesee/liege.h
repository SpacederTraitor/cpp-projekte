#ifndef LIEGE_H
#define LIEGE_H

class Liege
{
public:
    Liege();
};

#endif // LIEGE_H
