#ifndef PERSON_H
#define PERSON_H
#include <random>

class Person
{
public:
    Person();
    int Personenanzahlzumtestsetzen(Person* p);

private:
    int personen;
};

#endif // PERSON_H
