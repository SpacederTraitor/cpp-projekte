#ifndef SEE_H
#define SEE_H

#include <random>
#include <vector>
#include "person.h"

class See
{
public:
    See();
int getWassertemperaturaktuell();
int getWasserqualitaet();
int getPersonenanzahl();


private:
    int wassertemperaturaktuell;
    int wasserqualitaet;
    int personenanzahl;
    std::vector<Person *> personen;
};


#endif // SEE_H
