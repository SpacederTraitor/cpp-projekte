#ifndef GUI_H
#define GUI_H

class GUI
{
public:
    GUI();
};

#endif // GUI_H
