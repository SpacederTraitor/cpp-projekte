#include "daten.h"


void Daten::setZahl1(int newZahl1){
    zahl1 = newZahl1;
}

int Daten::getZahl1() {
    return zahl1;
}
void Daten::setZahl2(int newZahl2){
    zahl2 = newZahl2;
}

int Daten::getZahl2() {
    return zahl2;
}

void Daten::setErgebnis(int ergebnis){
    ergebnis = ergebnis;
}

int Daten::getErgebnis() {
    return ergebnis;
}
