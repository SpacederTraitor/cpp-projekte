#include "rechner.h"

Rechner::Rechner()
{

}


void Rechner::add() {
   daten.setErgebnis(daten.getZahl1() + daten.getZahl2());
}

void Rechner::setZahl1(int newZahl1){
    daten.setZahl1(newZahl1);
}



void Rechner::setZahl2(int newZahl2){
    daten.setZahl2(newZahl2);
}

int Rechner::getErgebnis(){
    daten.getErgebnis();
}
