#include <iostream>
#include "ui.h"

using namespace std;

int main()
{
    Ui myUi;
    myUi.eingabe();
    return 0;
}
