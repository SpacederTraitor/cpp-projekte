#ifndef UI_H
#define UI_H
#include "rechner.h"

class Ui
{
public:
    void eingabe();
    void loadData();

private:
    Rechner myRechner;
};

#endif // UI_H
